"""
__author__ = Alex Shah
__version__ = proj3
"""

from proj.proj1 import process_files
from proj.proj2 import recursive_process_files
from proj.proj3 import huffman_process_files
